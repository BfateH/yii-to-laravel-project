<?php

use App\Http\Controllers\AccountController;
use Illuminate\Support\Facades\Route;
use \App\MoonShine\Controllers\OrderStatus;

// Для удаления аккаунта при переходе по ссылке из email
//Route::get('/moonshine/profile/delete-confirm/{token}', [AccountController::class, 'confirmDelete'])
//    ->name('moonshine.profile.delete.confirm');

// Защищённые роуты, используемые moonshine
Route::middleware('auth:moonshine')->prefix('moonshine')->group(function () {

    Route::post('/admin/orders/orders-statuses', [OrderStatus::class, 'store'])
        ->name('moonshine.admin.orders.statuses.store');

    Route::post('/moonshine/profile/update', [AccountController::class, 'store'])
        ->name('moonshine.profile.update');
});


