<?php


return [
    'tbank' => [
        'name' => 'tbank',
        'display_name' => 'Т-Банк',
        'required_fields' => [
            'terminal_key' => '',
            'password' => '',
            'secret_key' => ''
        ],
        'description' => 'Т-Банк Acquiring integration'
    ],
    'test' => [
        'name' => 'test',
        'display_name' => 'Тест',
        'required_fields' => [
            'terminal_key' => '',
            'password' => '',
            'secret_key' => ''
        ],
        'description' => 'Т-Банк Acquiring integration'
    ],
];
