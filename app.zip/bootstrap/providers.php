<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CurrencyModuleServiceProvider::class,
    App\Providers\MoonShineServiceProvider::class,
    App\Providers\UserServiceProvider::class,
];
