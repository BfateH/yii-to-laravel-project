<td <?php echo e($attributes); ?>>
    <?php echo $slot ?? ''; ?>

</td>
<?php /**PATH F:\projects\with-moonshine\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/table/td.blade.php ENDPATH**/ ?>