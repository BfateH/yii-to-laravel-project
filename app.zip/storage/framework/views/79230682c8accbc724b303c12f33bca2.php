<!DOCTYPE html>
<html>
<head>
    <title>Подтверждение удаления аккаунта</title>
</head>
<body>
<h1>Подтвердите удаление аккаунта</h1>
<p>Для подтверждения удаления аккаунта перейдите по ссылке:</p>
<a href="<?php echo e(route('moonshine.profile.delete.confirm', $token)); ?>">
    Подтвердить удаление
</a>
<p>Если вы не запрашивали удаление, проигнорируйте это письмо.</p>
</body>
</html>
<?php /**PATH F:\projects\with-moonshine\resources\views/emails/account-delete.blade.php ENDPATH**/ ?>