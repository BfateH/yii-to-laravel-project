<?php echo $content; ?>

<?php /**PATH F:\projects\with-moonshine\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/flexible-render.blade.php ENDPATH**/ ?>