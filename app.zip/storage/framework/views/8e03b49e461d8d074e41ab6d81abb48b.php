<?php echo $layout; ?>

<?php /**PATH F:\projects\with-moonshine\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/page.blade.php ENDPATH**/ ?>