<th <?php echo e($attributes); ?>>
    <?php echo $slot ?? ''; ?>

</th>
<?php /**PATH F:\projects\with-moonshine\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/components/table/th.blade.php ENDPATH**/ ?>