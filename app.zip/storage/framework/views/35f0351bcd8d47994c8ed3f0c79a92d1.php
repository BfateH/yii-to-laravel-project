<div
    <?php echo e($attributes->only(['data-for-component'])->merge(['class' => 'hidden-ids'])); ?>

>
</div>
<?php /**PATH F:\projects\with-moonshine\vendor\moonshine\moonshine\src\Laravel\src\Providers/../../../UI/resources/views/fields/hidden-ids.blade.php ENDPATH**/ ?>