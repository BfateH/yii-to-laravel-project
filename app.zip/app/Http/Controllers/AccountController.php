<?php

namespace App\Http\Controllers;

use App\Services\AcquirerSettingsService;
use App\Services\UserService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use MoonShine\Laravel\Contracts\Notifications\MoonShineNotificationContract;
use MoonShine\Laravel\Http\Controllers\MoonShineController;
use MoonShine\Laravel\Http\Requests\ProfileFormRequest;
use MoonShine\Support\Enums\ToastType;
use Symfony\Component\HttpFoundation\Response;

class AccountController extends MoonShineController
{
    protected AcquirerSettingsService $acquirerService;
    protected UserService $userService;

    public function __construct(
        MoonShineNotificationContract $notification,
        AcquirerSettingsService $acquirerService,
        UserService $userService
    ) {
        parent::__construct($notification);
        $this->acquirerService = $acquirerService;
        $this->userService = $userService;
    }

    public function confirmDelete($token): \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
    {
        $user = \App\Models\User::query()
            ->where('delete_confirmation_token', $token)
            ->where('delete_requested_at', '>', now()->subHours(24))
            ->first();

        if (!$user) {
            return redirect(route('moonshine.login'))
                ->withErrors(['error' => 'Ссылка на удаление аккаунта не действительна.']);
        }

        try {
            $this->userService->forceDelete($user);
            return redirect(route('moonshine.login'))
                ->with('success', 'Аккаунт успешно удален.');
        } catch (\Exception $e) {
            Log::error('Error force deleting user: ' . $e->getMessage());
            return redirect(route('moonshine.login'))
                ->withErrors(['error' => 'Произошла ошибка при удалении аккаунта.']);
        }
    }

    public function store(ProfileFormRequest $request): Response
    {
        try {
            $user = Auth::user();

            // Фильтруем данные для таблицы users
            $filteredData = $this->acquirerService->filterRequestData(request()->all());

            if (!empty($filteredData)) {
                $user->fill($filteredData);
            }

            // Сохраняем основные данные пользователя
            $user->save();

            // Обрабатываем данные эквайринга только для партнеров
            if ($user->isPartnerRole()) {
                $this->acquirerService->saveAcquirerSettings($user, request()->all());
            }

            $message = __('moonshine::ui.saved');
            $type = ToastType::SUCCESS;

        } catch (\Exception $e) {
            Log::error('Profile save error: ' . $e->getMessage());
            $message = 'Произошла ошибка при сохранении профиля: ' . $e->getMessage();
            $type = ToastType::ERROR;
        }

        if ($request->ajax()) {
            return $this->json(message: $message, messageType: $type);
        }

        $this->toast($message, $type);
        return back();
    }
}
