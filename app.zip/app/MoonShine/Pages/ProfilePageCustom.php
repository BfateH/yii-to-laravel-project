<?php

namespace App\MoonShine\Pages;

use App\Services\UserService;
use App\Services\AcquirerSettingsService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use MoonShine\Contracts\Core\DependencyInjection\CoreContract;
use MoonShine\Contracts\UI\FormBuilderContract;
use MoonShine\Laravel\Http\Responses\MoonShineJsonResponse;
use MoonShine\Laravel\MoonShineAuth;
use MoonShine\Laravel\MoonShineRequest;
use MoonShine\Laravel\Notifications\MoonShineDatabaseNotification;
use MoonShine\Laravel\Pages\ProfilePage;
use MoonShine\Laravel\TypeCasts\ModelCaster;
use MoonShine\Support\Enums\Color;
use MoonShine\Support\Enums\ToastType;
use MoonShine\UI\Components\ActionButton;
use MoonShine\UI\Components\Badge;
use MoonShine\UI\Components\FormBuilder;
use MoonShine\UI\Components\Heading;
use MoonShine\UI\Components\Layout\Box;
use MoonShine\UI\Components\Tabs;
use MoonShine\UI\Components\Tabs\Tab;
use MoonShine\UI\Fields\ID;
use MoonShine\UI\Fields\Image;
use MoonShine\UI\Fields\Json;
use MoonShine\UI\Fields\Password;
use MoonShine\UI\Fields\PasswordRepeat;
use MoonShine\UI\Fields\Select;
use MoonShine\UI\Fields\Text;

class ProfilePageCustom extends ProfilePage
{
    protected ?string $alias = 'profile-page';

    private UserService $userService;
    private AcquirerSettingsService $acquirerService;

    public function __construct(CoreContract $core)
    {
        parent::__construct($core);
        $this->userService = app(UserService::class);
        $this->acquirerService = app(AcquirerSettingsService::class);
    }

    protected function fields(): iterable
    {
        $userFields = array_filter([
            ID::make()->sortable(),

            moonshineConfig()->getUserField('name')
                ? Text::make(__('moonshine::ui.resource.name'), moonshineConfig()->getUserField('name'))
                ->required()
                : null,

            moonshineConfig()->getUserField('username')
                ? Text::make(__('moonshine::ui.login.username'), moonshineConfig()->getUserField('username'))
                ->required()
                : null,

            moonshineConfig()->getUserField('avatar')
                ? Image::make(__('moonshine::ui.resource.avatar'), moonshineConfig()->getUserField('avatar'))
                ->disk(moonshineConfig()->getDisk())
                ->options(moonshineConfig()->getDiskOptions())
                ->dir('moonshine_users')
                ->removable()
                ->allowedExtensions(['jpg', 'png', 'jpeg', 'gif'])
                : null,
        ]);

        $userPasswordsFields = moonshineConfig()->getUserField('password') ? [
            Heading::make(__('moonshine::ui.resource.change_password')),

            Password::make(__('moonshine::ui.resource.password'), moonshineConfig()->getUserField('password'))
                ->customAttributes(['autocomplete' => 'new-password'])
                ->eye(),

            PasswordRepeat::make(__('moonshine::ui.resource.repeat_password'), 'password_repeat')
                ->customAttributes(['autocomplete' => 'confirm-password'])
                ->eye(),
        ] : [];

        $deleteFields = [
            Text::make()
                ->badge(Color::WARNING)
                ->setValue('После удаления аккаунта все ваши данные будут безвозвратно удалены.')
                ->previewMode(),

            ActionButton::make('Запросить удаление аккаунта', '#')
                ->method('sendDeleteRequest')
                ->showInLine()
                ->icon('trash')
                ->withConfirm('Вы уверены, что хотите удалить аккаунт?', '')
                ->error()
        ];

        $isPartner = $this->isUserPartner();
        $tabs = [
            Tab::make(__('moonshine::ui.resource.main_information'), $userFields)->icon('information-circle'),
            Tab::make(__('moonshine::ui.resource.password'), $userPasswordsFields)->canSee(
                fn(): bool => $userPasswordsFields !== [],
            )->icon('key'),
            Tab::make(__('moonshine::ui.resource.delete_information'), $deleteFields)->icon('hand-raised'),
        ];

        if ($isPartner) {
            $acquirers = config('acquirers', []);
            $acquirerOptions = [];
            foreach ($acquirers as $key => $acquirer) {
                $acquirerOptions[$key] = $acquirer['display_name'] ?? $acquirer['name'] ?? $key;
            }

            $acquireFields = [
                Select::make('Выберите эквайринг', 'selected_acquirer')
                    ->options($acquirerOptions)
                    ->nullable()
                    ->default($this->getDefaultSelectedAcquirer()),
                Badge::make($this->getRequiredFieldsText($acquirers)),
                ...$this->getAcquirerFields($acquirers)
            ];

            $tabs = array_merge(
                [Tab::make(__('moonshine::ui.resource.main_information'), $userFields)->icon('information-circle')],
                [Tab::make(__('Эквайринг'), $acquireFields)->icon('credit-card')],
                [Tab::make(__('moonshine::ui.resource.password'), $userPasswordsFields)->canSee(
                    fn(): bool => $userPasswordsFields !== [],
                )->icon('key')],
                [Tab::make(__('moonshine::ui.resource.delete_information'), $deleteFields)->icon('hand-raised')]
            );
        }

        return [
            Box::make([
                Tabs::make($tabs),
            ]),
        ];
    }

    /**
     * Проверяет, является ли текущий пользователь партнером
     */
    private function isUserPartner(): bool
    {
        $user = Auth::user();
        return $user && $user->isPartnerRole();
    }

    private function getDefaultSelectedAcquirer(): ?string
    {
        // Проверяем, является ли пользователь партнером
        if (!$this->isUserPartner()) {
            return null;
        }

        $item = Auth::user();

        if ($item && $item->exists) {
            $partner = $item->partner ?? $item->load('partner')->partner ?? null;
            if ($partner && isset($partner->acquirer_settings)) {
                $settings = $partner->acquirer_settings;
                if (isset($settings['selected_acquirer'])) {
                    return $settings['selected_acquirer'];
                }
            }
        }
        return null;
    }

    private function getRequiredFieldsText(array $acquirers): string
    {
        $parts = [];

        foreach ($acquirers as $key => $acquirer) {
            $displayName = $acquirer['display_name'] ?? $acquirer['name'] ?? $key;
            $line = "Для эквайринга <b>{$displayName}</b> обязательные поля:<br>";

            if (isset($acquirer['required_fields']) && is_array($acquirer['required_fields'])) {
                $requiredFieldNames = array_keys($acquirer['required_fields']);
                $line .= implode(', ', $requiredFieldNames);
            } else {
                $line .= "Нет обязательных полей";
            }

            $parts[] = $line;
        }

        return implode('<br><br>', $parts);
    }

    private function getAcquirerFields(array $acquirers): array
    {
        // Проверяем, является ли пользователь партнером
        if (!$this->isUserPartner()) {
            return [];
        }

        // Получаем текущий элемент
        $item = Auth::user();
        $defaultSettings = [];

        // Загружаем сохраненные настройки из таблицы partners
        if ($item && $item->exists) {
            $partner = $item->partner ?? $item->load('partner')->partner ?? null;
            if ($partner && isset($partner->acquirer_settings)) {
                $settings = $partner->acquirer_settings;
                if (isset($settings['settings'])) {
                    $defaultSettings = $settings['settings'];
                }
            }
        }

        return [Json::make("", "settings")
            ->keyValue(
                keyField: Text::make('Ключ')
                    ->customAttributes(['placeholder' => 'Введите ключ']),
                valueField: Text::make('Значение')
                    ->customAttributes(['placeholder' => 'Введите значение'])
            )
            ->creatable(
                button: ActionButton::make('Добавить ключ-значение')->primary()
            )
            ->removable()
            ->default($defaultSettings)
        ];
    }

    public function sendDeleteRequest(MoonShineRequest $request)
    {
        try {
            $user = Auth::user();

            $this->userService->requestDeletion($user);

            // Отправка уведомления
            $user->notify(new \App\Notifications\AccountDeletionRequested($user));

            return MoonShineJsonResponse::make()
                ->toast('Письмо для подтверждения удаления аккаунта отправлено на ваш email.', ToastType::SUCCESS);
        } catch (\Exception $e) {
            Log::error('Error sendDeleteRequest Exception: ' . $e->getMessage());

            return MoonShineJsonResponse::make()
                ->toast('Произошла ошибка при создании запроса на удаление аккаунта.', ToastType::ERROR);
        }
    }

    public function getForm(): FormBuilderContract
    {
        $user = MoonShineAuth::getGuard()->user() ?? MoonShineAuth::getModel();

        return FormBuilder::make(action([\App\Http\Controllers\AccountController::class, 'store']))
            ->async()
            ->fields($this->fields())
            ->fillCast($user, new ModelCaster($user::class))
            ->submit(__('moonshine::ui.save'), [
                'class' => 'btn-lg btn-primary',
            ]);
    }
}
