<?php

declare(strict_types=1);

namespace App\MoonShine\Layouts;

use App\Modules\OrderManagement\MoonShine\Resources\OrderResource;
use App\Modules\OrderManagement\MoonShine\Resources\PackageResource;
use App\MoonShine\Resources\PartnerResource;
use App\MoonShine\Resources\UserResource;
use Illuminate\Support\Facades\Auth;
use MoonShine\ColorManager\ColorManager;
use MoonShine\Contracts\ColorManager\ColorManagerContract;
use MoonShine\Laravel\Layouts\AppLayout;
use MoonShine\Laravel\Resources\MoonShineUserRoleResource;
use MoonShine\MenuManager\MenuItem;
use MoonShine\UI\Components\{Layout\Footer, Layout\Layout};

final class MoonShineLayout extends AppLayout
{
    protected function assets(): array
    {
        return [
            ...parent::assets(),
        ];
    }

    protected function menu(): array
    {
        return [
            MenuItem::make('Пользователи', UserResource::class),
            MenuItem::make('Партнеры', PartnerResource::class)->canSee(fn() => Auth::user()->isAdminRole()),
            MenuItem::make(
                static fn () => __('moonshine::ui.resource.role_title'),
                MoonShineUserRoleResource::class
            )->canSee(fn() => Auth::user()->isAdminRole()),
            MenuItem::make('Заказы', OrderResource::class)->icon('shopping-cart'),
            MenuItem::make('Посылки', PackageResource::class)->icon('cube'),
        ];
    }

    /**
     * @param ColorManager $colorManager
     */
    protected function colors(ColorManagerContract $colorManager): void
    {
        parent::colors($colorManager);

        // $colorManager->primary('#00000');
    }

    protected function getFooterCopyright(): string
    {
        return '';
    }

    protected function getFooterComponent(): Footer
    {
        return parent::getFooterComponent()->menu([]);
    }

    public function build(): Layout
    {
        return parent::build();
    }
}
