<?php

namespace App\MoonShine\Resources;

use App\Enums\Role;
use App\Models\User;
use App\MoonShine\Traits\HasUserActions;
use App\Services\UserService;
use Illuminate\Contracts\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;
use MoonShine\Contracts\Core\DependencyInjection\CoreContract;
use MoonShine\Contracts\UI\ActionButtonContract;
use MoonShine\Laravel\Enums\Ability;
use MoonShine\Laravel\Enums\Action;
use MoonShine\Laravel\Models\MoonshineUserRole;
use MoonShine\Laravel\Resources\ModelResource;
use MoonShine\Support\Attributes\Icon;
use MoonShine\Support\Enums\Color;
use MoonShine\Support\ListOf;
use MoonShine\UI\Components\ActionButton;
use MoonShine\UI\Components\Collapse;
use MoonShine\UI\Components\Layout\Box;
use MoonShine\UI\Components\Layout\Flex;
use MoonShine\UI\Components\Tabs;
use MoonShine\UI\Components\Tabs\Tab;
use MoonShine\UI\Fields\Date;
use MoonShine\UI\Fields\Email;
use MoonShine\UI\Fields\Hidden;
use MoonShine\UI\Fields\ID;
use MoonShine\UI\Fields\Image;
use MoonShine\UI\Fields\Password;
use MoonShine\UI\Fields\PasswordRepeat;
use MoonShine\UI\Fields\Select;
use MoonShine\UI\Fields\Switcher;
use MoonShine\UI\Fields\Text;
use MoonShine\UI\Fields\Textarea;

#[Icon('users')]
abstract class BaseUserResource extends ModelResource
{
    use HasUserActions;

    protected string $model = User::class;
    protected string $column = 'name';
    protected array $with = ['moonshineUserRole'];
    protected bool $simplePaginate = true;
    protected bool $columnSelection = true;
    protected bool $indexButtonsInDropdown = true;

    protected UserService $userService;

    public function __construct(CoreContract $core)
    {
        parent::__construct($core);
        $this->userService = app(UserService::class);
    }

    protected function activeActions(): ListOf
    {
        return parent::activeActions()->except(Action::VIEW);
    }

    abstract protected function getResourceTitle(): string;
    abstract protected function getRoleFilter(): int;
    abstract protected function shouldShowPartnerField(): bool;

    public function getTitle(): string
    {
        return $this->getResourceTitle();
    }

    protected function modifyQueryBuilder(Builder $builder): Builder
    {
        $builder = $builder->where('role_id', $this->getRoleFilter());

        $currentUser = auth()->user();
        if ($currentUser && $currentUser->isPartnerRole()) {
            $builder->where('partner_id', $currentUser->id);
        }

        return $builder;
    }

    public function isCan(Ability $ability): bool
    {
        $user = auth()->user();
        return $user && ($user->isAdminRole() || $user->isPartnerRole());
    }

    protected function indexFields(): iterable
    {
        $currentUser = auth()->user();
        $fields = [
            ID::make()->sortable(),
        ];

        // Показываем колонку "Роль" только если это не PartnerResource
        if ($currentUser && $currentUser->isAdminRole() && !($this instanceof \App\MoonShine\Resources\PartnerResource)) {
            $fields[] = \MoonShine\Laravel\Fields\Relationships\BelongsTo::make(
                __('Роль'),
                'moonshineUserRole',
                formatted: static fn(MoonshineUserRole $model) => $model->name,
                resource: \App\MoonShine\Resources\MoonShineUserRoleResource::class,
            )->badge(Color::PURPLE);
        }

        $fields = array_merge($fields, [
            Text::make(__('Имя'), 'name'),
            Email::make(__('Email'), 'email')->sortable(),
        ]);

        // Показываем колонку "Партнер" только для UserResource и только админам
        if ($currentUser && $currentUser->isAdminRole() && $this->shouldShowPartnerField() && !($this instanceof \App\MoonShine\Resources\PartnerResource)) {
            $fields[] = Text::make(
                __('Партнер'),
                'assignedPartner.name'
            )->badge(Color::BLUE)->nullable();
        }

        $fields = array_merge($fields, [
            Switcher::make(__('Активен'), 'is_active')->sortable(),
            Switcher::make(__('Заблокирован'), 'is_banned')->sortable(),
            Date::make(__('Создан'), 'created_at')
                ->format("d.m.Y")
                ->sortable(),
        ]);

        return $fields;
    }

    protected function detailFields(): iterable
    {
        return $this->indexFields();
    }

    protected function formFields(): iterable
    {
        $currentUser = auth()->user();
        $isAdmin = $currentUser && $currentUser->isAdminRole();

        $basicFields = [
            ID::make()->sortable(),
        ];

        if ($isAdmin) {
            $basicFields[] = \MoonShine\Laravel\Fields\Relationships\BelongsTo::make(
                __('Роль'),
                'moonshineUserRole',
                formatted: static fn($model) => $model->name,
                resource: \App\MoonShine\Resources\MoonShineUserRoleResource::class,
            )
                ->valuesQuery(static fn(Builder $q) => $q->select(['id', 'name'])->where('id', '!=', Role::partner->value))
                ->onAfterApply(function ($item, $value) {
                    if ($value == Role::partner->value) {
                        return $item->role_id;
                    }
                    return $value;
                });

            if ($this->shouldShowPartnerField()) {
                $basicFields[] = \MoonShine\Laravel\Fields\Relationships\BelongsTo::make(
                    __('Партнер'),
                    'assignedPartner',
                    resource: \App\MoonShine\Resources\PartnerResource::class
                )
                    ->asyncSearch('name')
                    ->asyncOnInit(whenOpen: false)
                    ->valuesQuery(fn(Builder $query) => $query->where('role_id', Role::partner->value))
                    ->nullable()
                    ->placeholder(__('Выберите партнера'));
            }
        } else {
            $basicFields[] = Hidden::make('partner_id')
                ->default($currentUser->id)
                ->fill($currentUser->id);
        }

        $basicFields = array_merge([
            Flex::make([
                Text::make(__('Имя'), 'name')->required(),
                Email::make(__('Email'), 'email')->required(),
            ]),
            Image::make(__('Аватар'), 'avatar')
                ->disk(moonshineConfig()->getDisk())
                ->dir('moonshine_users')
                ->allowedExtensions(['jpg', 'png', 'jpeg', 'gif']),
        ], $basicFields);

        return [
            Box::make([
                Tabs::make([
                    Tab::make(__('Основная информация'), $basicFields)->icon('user-circle'),
                    Tab::make(__('Статус и безопасность'), [
                        Switcher::make(__('Активен'), 'is_active'),
                        Switcher::make(__('Заблокирован'), 'is_banned'),
                        Textarea::make(__('Причина блокировки'), 'ban_reason'),
                        Date::make(__('Запрос на удаление'), 'delete_requested_at')
                            ->withTime()
                            ->readonly(),
                    ])->icon('shield-check'),
                    Tab::make(__('Пароль'), [
                        Collapse::make(__('Смена пароля'), [
                            Password::make(__('Пароль'), 'password')
                                ->customAttributes(['autocomplete' => 'new-password'])
                                ->eye(),
                            PasswordRepeat::make(__('Повторите пароль'), 'password_repeat')
                                ->customAttributes(['autocomplete' => 'confirm-password'])
                                ->eye(),
                        ])->icon('lock-closed'),
                    ])->icon('lock-closed'),
                ]),
            ]),
        ];
    }

    protected function rules($item): array
    {
        $currentUser = auth()->user();
        $isAdmin = $currentUser && $currentUser->isAdminRole();

        $rules = [
            'name' => 'required',
            'email' => [
                'required',
                'bail',
                'email',
                Rule::unique('users')->ignoreModel($item),
            ],
            'avatar' => ['sometimes', 'nullable', 'image', 'mimes:jpeg,jpg,png,gif'],
            'password' => $item->exists
                ? 'sometimes|nullable|min:6|required_with:password_repeat|same:password_repeat'
                : 'required|min:6|required_with:password_repeat|same:password_repeat',
            'is_active' => 'boolean',
            'is_banned' => 'boolean',
            'banned_at' => 'nullable|date',
            'ban_reason' => 'nullable|string|max:500',
            'delete_requested_at' => 'nullable|date',
        ];

        if ($isAdmin) {
            $rules['role_id'] = [
                'required',
                'not_in:' . Role::partner->value,
                'exists:moonshine_user_roles,id'
            ];

            if ($this->shouldShowPartnerField()) {
                $rules['partner_id'] = [
                    'nullable',
                    'exists:users,id',
                    function ($attribute, $value, $fail) {
                        if (is_null($value)) {
                            return;
                        }

                        $partner = User::find($value);
                        if (!$partner || !$partner->isPartnerRole()) {
                            $fail('Выбранный пользователь не является партнером.');
                        }
                    },
                ];
            }
        } else {
            $rules['partner_id'] = 'required|exists:users,id';
        }

        return $rules;
    }

    protected function search(): array
    {
        $currentUser = auth()->user();
        $searchable = [
            'role_id',
            'email',
            'is_active',
            'is_banned',
        ];

        if ($currentUser && $currentUser->isAdminRole() && $this->shouldShowPartnerField()) {
            $searchable[] = 'partner_id';
        }

        return $searchable;
    }

    protected function filters(): iterable
    {
        $currentUser = auth()->user();
        $filters = [];

        if ($currentUser && $currentUser->isAdminRole()) {
            $filters[] = \MoonShine\Laravel\Fields\Relationships\BelongsTo::make(
                __('Роль'),
                'moonshineUserRole',
                formatted: static fn(MoonshineUserRole $model) => $model->name,
                resource: \App\MoonShine\Resources\MoonShineUserRoleResource::class,
            )->valuesQuery(static fn(Builder $q) => $q->select(['id', 'name'])->where('id', '!=', Role::partner->value))->nullable();

            if ($this->shouldShowPartnerField()) {
                $filters[] = \MoonShine\Laravel\Fields\Relationships\BelongsTo::make(
                    __('Партнер'),
                    'assignedPartner',
                    resource: \App\MoonShine\Resources\PartnerResource::class
                )
                    ->nullable()
                    ->asyncSearch('name')
                    ->asyncOnInit()
                    ->valuesQuery(fn(Builder $query) => $query->where('role_id', Role::partner->value))
                    ->placeholder(__('Выберите партнера'))
                    ->default(null)
                ;
            }
        }

        $filters = array_merge($filters, [
            Text::make('Email', 'email')->nullable(),
            \MoonShine\UI\Fields\Select::make('Активен', 'is_active')
                ->options([
                    null => 'Все',
                    0 => 'Не активен',
                    1 => 'Активен',
                ]),
            \MoonShine\UI\Fields\Select::make('Заблокирован', 'is_banned')
                ->options([
                    null => 'Все',
                    0 => 'Не заблокирован',
                    1 => 'Заблокирован',
                ]),
        ]);

        $filters[] = Switcher::make('Удаленные пользователи', 'with_trashed')
            ->onApply(fn(Builder $builder, $value) => $value ? $builder->onlyTrashed() : $builder)
            ->default(false);

        return $filters;
    }

    protected function modifyEditButton(ActionButtonContract $button): ActionButtonContract
    {
        return $button->setLabel('Редактировать');
    }

    protected function modifyDeleteButton(ActionButtonContract $button): ActionButtonContract
    {
        return $button->setLabel('Удалить');
    }

    public function indexButtons(): ListOf
    {
        $indexButtons = new ListOf(ActionButtonContract::class, []);

        $indexButtons = $indexButtons->add(
            ActionButton::make('Полное удаление', '#')
                ->method('forceDelete')
                ->showInLine()
                ->icon('trash')
                ->error()
                ->withConfirm(
                    'Подтверждение полного удаления',
                    'Внимание! Это действие необратимо. Все данные пользователя будут полностью удалены.',
                    'Удалить навсегда'
                )
                ->canSee(fn(User $user) => $user->trashed() && $user->id !== 1),

            ActionButton::make('Восстановить', '#')
                ->method('restore')
                ->showInLine()
                ->icon('arrow-path')
                ->success()
                ->canSee(fn(User $user) => $user->trashed())
        );

        $indexButtons = $indexButtons->add(
            $this->getEditButton(isAsync: $this->isAsync())
                ->canSee(fn(User $user) => !$user->trashed()),

            $this->getDeleteButton(
                redirectAfterDelete: $this->getRedirectAfterDelete(),
                isAsync: $this->isAsync()
            )
                ->canSee(fn(User $user) => !$user->trashed() && $user->id !== 1),

            ActionButton::make('Активировать', '#')
                ->method('activate')
                ->canSee(fn(User $user) => !$user->trashed() && !$user->is_active)
                ->showInLine()
                ->icon('check')
                ->success(),

            ActionButton::make('Деактивировать', '#')
                ->method('deactivate')
                ->canSee(fn(User $user) => !$user->trashed() && $user->is_active)
                ->showInLine()
                ->icon('x-mark')
                ->warning(),

            ActionButton::make('Заблокировать', '#')
                ->method('ban')
                ->canSee(fn(User $user) => !$user->trashed() && !$user->is_banned)
                ->showInLine()
                ->icon('lock-closed')
                ->info()
                ->withConfirm(
                    'Подтверждение блокировки',
                    'Вы уверены, что хотите заблокировать этого пользователя?',
                    'Заблокировать'
                ),

            ActionButton::make('Разблокировать', '#')
                ->method('unban')
                ->canSee(fn(User $user) => !$user->trashed() && $user->is_banned)
                ->showInLine()
                ->icon('lock-open')
                ->success()
        );

        return $indexButtons;
    }

    // Универсальные проверки через Policy
    protected function canUpdateItem(mixed $item): bool|string
    {
        return Gate::forUser(auth()->user())->allows('update', $item) ?: __('Недостаточно прав для редактирования.');
    }

    protected function canForceDeleteItem(mixed $item): bool|string
    {
        return Gate::forUser(auth()->user())->allows('forceDelete', $item) ?: __('Недостаточно прав для полного удаления.');
    }

    protected function beforeDeleting(mixed $item): mixed
    {
        // Для партнёров используем специфичную проверку
        if ($this instanceof \App\MoonShine\Resources\PartnerResource) {
            $checkResult = $this->canDeleteItem($item);
        } else {
            // Для остальных используем Policy
            $checkResult = $this->canDeleteItem($item);
        }

        if ($checkResult !== true) {
            throw new \Exception(is_string($checkResult) ? $checkResult : __('Недостаточно прав для удаления.'));
        }

        return $item;
    }

    protected function canDeleteItem(mixed $item): bool|string
    {
        $currentUser = auth()->user();

        if (!$currentUser) {
            return __('Пользователь не авторизован.');
        }

        // Нельзя удалять ID = 1
        if ($item->id === 1) {
            return __('Нельзя удалять пользователя с ID = 1');
        }

        return true;
    }

    public function findItem(bool $orFail = false): mixed
    {
        $item = parent::findItem($orFail);

        if ($item && !Gate::forUser(auth()->user())->allows('view', $item)) {
            if ($orFail) {
                abort(404, 'Пользователь не найден или не разрешен для этого ресурса.');
            }
            return null;
        }

        return $item;
    }

    protected function beforeUpdating(mixed $item): mixed
    {
        if (!Gate::forUser(auth()->user())->allows('update', $item)) {
            throw new \Exception(__('Недостаточно прав для редактирования.'));
        }

        $newRoleId = request()->input('role_id');
        if ($newRoleId && $newRoleId == Role::partner->value) {
            throw new \Exception('Невозможно назначить роль партнера через этот ресурс.');
        }

        $currentUser = auth()->user();
        if ($currentUser && $currentUser->isPartnerRole()) {
            if (request()->has('role_id')) {
                throw new \Exception('Партнер не может изменять роль пользователя.');
            }
            if (request()->has('partner_id') && request()->input('partner_id') != $currentUser->id) {
                throw new \Exception('Партнер не может изменять привязку к другому партнеру.');
            }
        }

        return $item;
    }

    protected function beforeCreating(mixed $item): mixed
    {
        $currentUser = auth()->user();
        if ($currentUser && $currentUser->isPartnerRole()) {
            $item->partner_id = $currentUser->id;
        }

        return $item;
    }

    protected function afterUpdated(mixed $item): mixed
    {
        $changes = $item->getChanges();
        if (isset($changes['is_banned'])) {
            $isBanned = $changes['is_banned'];

            if ($isBanned) {
                $this->userService->ban($item, request()->input('ban_reason'));
            } else {
                $this->userService->unban($item);
            }
        }

        return $item;
    }
}
