<?php

namespace App\MoonShine\Resources;

use App\Enums\Role;
use MoonShine\Contracts\Core\DependencyInjection\CoreContract;
use MoonShine\MenuManager\Attributes\Group;
use MoonShine\MenuManager\Attributes\Order;
use MoonShine\Support\Attributes\Icon;

#[Icon('users')]
#[Group('moonshine::ui.resource.system', 'users', translatable: true)]
#[Order(1)]
class UserResource extends BaseUserResource
{
    public function __construct(CoreContract $core)
    {
        parent::__construct($core);
    }

    protected function getResourceTitle(): string
    {
        return __('Пользователи');
    }

    protected function getRoleFilter(): int
    {
        // Не фильтруем по конкретной роли, а исключаем партнеров в modifyQueryBuilder
        return 0; // Заглушка
    }

    protected function shouldShowPartnerField(): bool
    {
        return true;
    }

    protected function modifyQueryBuilder(\Illuminate\Contracts\Database\Eloquent\Builder $builder): \Illuminate\Contracts\Database\Eloquent\Builder
    {
         $filters = request()->query('filter', []);
         $withTrashedValue = $filters['with_trashed'] ?? null;

        // Исключаем партнеров
        $builder = $builder->where('role_id', '!=', Role::partner->value);

        $currentUser = auth()->user();
        if ($currentUser && $currentUser->isPartnerRole()) {
            $builder->where('partner_id', $currentUser->id);
        }

        if ($withTrashedValue) {
            $builder->onlyTrashed();
        }

        return $builder;
    }
}
