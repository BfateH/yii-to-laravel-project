<?php

namespace App\MoonShine\Resources;

use App\Enums\Role;
use App\Services\AcquirerSettingsService;
use Illuminate\Contracts\Database\Eloquent\Builder;
use Illuminate\Validation\Rule;
use MoonShine\Contracts\Core\DependencyInjection\CoreContract;
use MoonShine\Contracts\UI\ActionButtonContract;
use MoonShine\Laravel\Enums\Ability;
use MoonShine\MenuManager\Attributes\Group;
use MoonShine\MenuManager\Attributes\Order;
use MoonShine\Support\Attributes\Icon;
use MoonShine\UI\Components\Badge;
use MoonShine\UI\Components\Collapse;
use MoonShine\UI\Components\Layout\Box;
use MoonShine\UI\Components\Layout\Flex;
use MoonShine\UI\Components\Tabs;
use MoonShine\UI\Components\Tabs\Tab;
use MoonShine\UI\Fields\Date;
use MoonShine\UI\Fields\Email;
use MoonShine\UI\Fields\Hidden;
use MoonShine\UI\Fields\ID;
use MoonShine\UI\Fields\Image;
use MoonShine\UI\Fields\Password;
use MoonShine\UI\Fields\PasswordRepeat;
use MoonShine\UI\Fields\Select;
use MoonShine\UI\Fields\Switcher;
use MoonShine\UI\Fields\Text;
use MoonShine\UI\Fields\Textarea;

#[Icon('briefcase')]
#[Group('Партнеры')]
#[Order(2)]
class PartnerResource extends BaseUserResource
{
    protected AcquirerSettingsService $acquirerService;

    public function __construct(CoreContract $core)
    {
        parent::__construct($core);
        $this->acquirerService = app(AcquirerSettingsService::class);
    }

    public function getTitle(): string
    {
        return __('Партнеры');
    }

    public function isCan(Ability $ability): bool
    {
        $user = auth()->user();
        return $user && $user->isAdminRole();
    }

    protected function getResourceTitle(): string
    {
        return __('Партнеры');
    }

    protected function getRoleFilter(): int
    {
        return Role::partner->value;
    }

    protected function shouldShowPartnerField(): bool
    {
        return false;
    }

    // Переопределяем query builder для партнёров
    protected function modifyQueryBuilder(Builder $builder): Builder
    {
        $filters = request()->query('filter', []);
        $withTrashedValue = $filters['with_trashed'] ?? null;

        if ($withTrashedValue) {
            $builder->onlyTrashed();
        }

        return $builder->where('role_id', Role::partner->value);
    }

    protected function formFields(): iterable
    {
        $acquirers = config('acquirers', []);
        $acquirerOptions = [];
        foreach ($acquirers as $key => $acquirer) {
            $acquirerOptions[$key] = $acquirer['display_name'] ?? $acquirer['name'] ?? $key;
        }

        return [
            Box::make([
                Tabs::make([
                    Tab::make(__('Основная информация'), [
                        ID::make()->sortable(),
                        Hidden::make('role_id')
                            ->default(Role::partner->value)
                            ->fill(Role::partner->value)
                            ->onAfterApply(fn($item, $value) => Role::partner->value),

                        Flex::make([
                            Text::make(__('Имя'), 'name')->required(),
                            Email::make(__('Email'), 'email')->required(),
                        ]),

                        Image::make(__('Аватар'), 'avatar')
                            ->disk(moonshineConfig()->getDisk())
                            ->dir('moonshine_users')
                            ->allowedExtensions(['jpg', 'png', 'jpeg', 'gif']),

                        Collapse::make(__('Пароль'), [
                            Password::make(__('Пароль'), 'password')
                                ->customAttributes(['autocomplete' => 'new-password'])
                                ->eye(),

                            PasswordRepeat::make(__('Повторите пароль'), 'password_repeat')
                                ->customAttributes(['autocomplete' => 'confirm-password'])
                                ->eye(),
                        ])->icon('lock-closed'),

                    ])->icon('user-circle'),

                    Tab::make(__('Эквайринг'), [
                        Select::make('Выберите эквайринг', 'selected_acquirer')
                            ->options($acquirerOptions)
                            ->nullable()
                            ->default($this->acquirerService->getDefaultSelectedAcquirer($this->getItem())),
                        Badge::make($this->acquirerService->getRequiredFieldsText($acquirers)),
                        ...$this->acquirerService->getAcquirerFields($acquirers, $this->getItem())
                    ])->icon('credit-card'),

                    Tab::make(__('Статус и безопасность'), [
                        Switcher::make(__('Активен'), 'is_active'),
                        Switcher::make(__('Заблокирован'), 'is_banned'),
                        Textarea::make(__('Причина блокировки'), 'ban_reason'),
                        Date::make(__('Запрос на удаление'), 'delete_requested_at')
                            ->withTime()
                            ->readonly(),
                    ])->icon('shield-check'),

                ]),
            ]),
        ];
    }

    protected function rules(mixed $item): array
    {
        return [
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                'max:255',
                Rule::unique('users')->ignoreModel($item),
            ],
            'role_id' => 'required|in:' . Role::partner->value,
            'is_active' => 'boolean',
            'is_banned' => 'boolean',
            'password' => $item->exists
                ? 'sometimes|nullable|min:6|required_with:password_repeat|same:password_repeat'
                : 'required|min:6|required_with:password_repeat|same:password_repeat',
        ];
    }

    protected function search(): array
    {
        return [
            'name',
            'email',
        ];
    }

    protected function filters(): iterable
    {
        return [
            Text::make('Email', 'email')->nullable(),
            Select::make('Активен', 'is_active')
                ->options([
                    null => 'Все',
                    0 => 'Не активен',
                    1 => 'Активен',
                ]),
            Select::make('Заблокирован', 'is_banned')
                ->options([
                    null => 'Все',
                    0 => 'Не заблокирован',
                    1 => 'Заблокирован',
                ]),
            Switcher::make('Удаленные партнеры', 'with_trashed')
                ->onApply(fn(Builder $builder, $value) => $value ? $builder->onlyTrashed() : $builder)
                ->default(false),
        ];
    }

    // Переопределяем проверки прав для партнёров
    protected function canUpdateItem(mixed $item): bool|string
    {
        $currentUser = auth()->user();

        // Только админы могут редактировать партнёров
        if (!$currentUser || !$currentUser->isAdminRole()) {
            return __('Только администраторы могут редактировать партнеров.');
        }

        return true;
    }

    protected function canForceDeleteItem(mixed $item): bool|string
    {
        $currentUser = auth()->user();

        // Только админы могут удалять партнёров
        if (!$currentUser || !$currentUser->isAdminRole()) {
            return __('Только администраторы могут удалять партнеров.');
        }

        // Нельзя удалять ID = 1
        if ($item->id === 1) {
            return __('Нельзя удалять пользователя с ID = 1');
        }

        return true;
    }

    /**
     * Переопределяем метод save для предотвращения ошибки
     */
    public function save(mixed $item, ?\MoonShine\Contracts\Core\DependencyInjection\FieldsContract $fields = null): mixed
    {
        $data = request()->all();
        $filteredData = $this->acquirerService->filterRequestData($data);

        if (!empty($filteredData)) {
            $item->fill($filteredData);
        }

        if ($item->exists) {
            $item->save();
        } else {
            $item = $this->getModel()->query()->create($filteredData);
        }

        // Сохраняем настройки эквайринга
        $this->acquirerService->saveAcquirerSettings($item, $data);

        return $item;
    }

    /**
     * Переопределяем метод для корректной работы с удаленными партнерами
     */
    protected function modifyEditButton(ActionButtonContract $button): ActionButtonContract
    {
        return $button->setLabel('Редактировать');
    }

    protected function modifyDeleteButton(ActionButtonContract $button): ActionButtonContract
    {
        return $button->setLabel('Удалить');
    }
}
