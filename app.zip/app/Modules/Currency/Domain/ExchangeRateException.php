<?php

namespace App\Modules\Currency\Domain;

use Exception;

class ExchangeRateException extends Exception
{
    //
}
