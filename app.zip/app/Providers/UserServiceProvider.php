<?php

namespace App\Providers;

use App\Services\UserService;
use App\Services\PartnerService;
use App\Services\AcquirerSettingsService;
use App\Services\UserDeletionService;
use Illuminate\Support\ServiceProvider;

class UserServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->singleton(UserService::class, function ($app) {
            return new UserService();
        });

        $this->app->singleton(PartnerService::class, function ($app) {
            return new PartnerService();
        });

        $this->app->singleton(AcquirerSettingsService::class, function ($app) {
            return new AcquirerSettingsService();
        });

        $this->app->singleton(UserDeletionService::class, function ($app) {
            return new UserDeletionService();
        });
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
