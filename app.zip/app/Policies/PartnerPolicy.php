<?php

namespace App\Policies;

use App\Models\User;
use App\Enums\Role;
use Illuminate\Auth\Access\HandlesAuthorization;

class PartnerPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $authenticatedUser): bool
    {
        return $authenticatedUser->isAdminRole();
    }

    public function view(User $authenticatedUser, User $targetUser): bool
    {
        return $authenticatedUser->isAdminRole() && $targetUser->isPartnerRole();
    }

    public function create(User $authenticatedUser): bool
    {
        return $authenticatedUser->isAdminRole();
    }

    public function update(User $authenticatedUser, User $targetUser): bool
    {
        return $authenticatedUser->isAdminRole() && $targetUser->isPartnerRole();
    }

    public function delete(User $authenticatedUser, User $targetUser): bool
    {
        // Нельзя удалять админа (ID = 1)
        if ($targetUser->id === 1) {
            return false;
        }

        return $authenticatedUser->isAdminRole() && $targetUser->isPartnerRole();
    }

    public function restore(User $authenticatedUser, User $targetUser): bool
    {
        return $authenticatedUser->isAdminRole() && $targetUser->isPartnerRole();
    }

    public function forceDelete(User $authenticatedUser, User $targetUser): bool
    {
        // Нельзя удалять админа (ID = 1)
        if ($targetUser->id === 1) {
            return false;
        }

        return $authenticatedUser->isAdminRole() && $targetUser->isPartnerRole();
    }
}
