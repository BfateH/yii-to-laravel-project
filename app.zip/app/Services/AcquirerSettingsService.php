<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AcquirerSettingsService
{
    /**
     * Фильтрация данных запроса для таблицы users
     */
    public function filterRequestData(array $data): array
    {
        $filtered = [];

        $excludeKeys = [
            'selected_acquirer',
            'settings',
            'password_repeat',
        ];

        foreach ($data as $key => $value) {
            if (in_array($key, $excludeKeys)) {
                continue;
            }

            if ($key === 'password') {
                if (!empty($value)) {
                    $filtered[$key] = Hash::make($value);
                }
                continue;
            }

            $filtered[$key] = $value;
        }

        return $filtered;
    }

    /**
     * Сохранение настроек эквайринга
     */
    public function saveAcquirerSettings(User $user, array $requestData): void
    {
        try {
            $selectedAcquirer = $requestData['selected_acquirer'] ?? null;
            $settings = $requestData['settings'] ?? [];

            // Проверяем, существует ли связь с партнером
            $partner = $user->partner;

            if (!$partner) {
                $partner = $user->partner()->create([
                    'user_id' => $user->id
                ]);
            }

            $partnerData = [
                'selected_acquirer' => $selectedAcquirer,
                'settings' => $settings
            ];

            $partner->acquirer_settings = $partnerData;
            $partner->save();
        } catch (\Exception $e) {
            Log::error('Error saving acquirer settings: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Формирует текст с обязательными полями для всех эквайрингов
     */
    public function getRequiredFieldsText(array $acquirers): string
    {
        $parts = [];

        foreach ($acquirers as $key => $acquirer) {
            $displayName = $acquirer['display_name'] ?? $acquirer['name'] ?? $key;
            $line = "Для эквайринга <b>{$displayName}</b> обязательные поля:<br>";

            if (isset($acquirer['required_fields']) && is_array($acquirer['required_fields'])) {
                $requiredFieldNames = array_keys($acquirer['required_fields']);
                $line .= implode(', ', $requiredFieldNames);
            } else {
                $line .= "Нет обязательных полей";
            }

            $parts[] = $line;
        }

        return implode('<br><br>', $parts);
    }

    /**
     * Получение выбранного эквайринга по умолчанию
     */
    public function getDefaultSelectedAcquirer($item): ?string
    {
        if ($item && $item->exists) {
            $partner = $item->partner ?? $item->load('partner')->partner ?? null;
            if ($partner && isset($partner->acquirer_settings)) {
                $settings = $partner->acquirer_settings;
                if (isset($settings['selected_acquirer'])) {
                    return $settings['selected_acquirer'];
                }
            }
        }
        return null;
    }

    /**
     * Получение полей для настройки эквайринга
     */
    public function getAcquirerFields(array $acquirers, $item): array
    {
        $defaultSettings = [];

        // Загружаем сохраненные настройки
        if ($item && $item->exists) {
            $partner = $item->partner ?? $item->load('partner')->partner ?? null;
            if ($partner && isset($partner->acquirer_settings)) {
                $settings = $partner->acquirer_settings;
                if (isset($settings['settings'])) {
                    $defaultSettings = $settings['settings'];
                }
            }
        }

        return [\MoonShine\UI\Fields\Json::make("", "settings")
            ->keyValue(
                keyField: \MoonShine\UI\Fields\Text::make('Ключ')
                    ->customAttributes(['placeholder' => 'Введите ключ']),
                valueField: \MoonShine\UI\Fields\Text::make('Значение')
                    ->customAttributes(['placeholder' => 'Введите значение'])
            )
            ->creatable(
                button: \MoonShine\UI\Components\ActionButton::make('Добавить ключ-значение')->primary()
            )
            ->removable()
            ->default($defaultSettings)
        ];
    }
}
