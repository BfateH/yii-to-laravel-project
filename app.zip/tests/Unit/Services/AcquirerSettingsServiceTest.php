<?php

namespace Tests\Unit\Services;

use App\Enums\Role;
use App\Models\User;
use App\Services\AcquirerSettingsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AcquirerSettingsServiceTest extends TestCase
{
    use RefreshDatabase;

    protected AcquirerSettingsService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new AcquirerSettingsService();
    }

    public function test_it_filters_request_data_correctly()
    {
        $requestData = [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => 'secret123',
            'password_repeat' => 'secret123',
            'selected_acquirer' => 'tbank',
            'settings' => ['key' => 'value']
        ];

        $filtered = $this->service->filterRequestData($requestData);

        $this->assertArrayHasKey('name', $filtered);
        $this->assertArrayHasKey('email', $filtered);
        $this->assertArrayHasKey('password', $filtered);
        $this->assertArrayNotHasKey('password_repeat', $filtered);
        $this->assertArrayNotHasKey('selected_acquirer', $filtered);
        $this->assertArrayNotHasKey('settings', $filtered);
    }

    public function test_it_hashes_password_when_filtering()
    {
        $requestData = [
            'password' => 'secret123',
            'name' => 'Test User'
        ];

        $filtered = $this->service->filterRequestData($requestData);

        $this->assertNotEquals('secret123', $filtered['password']);
        $this->assertTrue(password_verify('secret123', $filtered['password']));
    }

    public function test_it_saves_acquirer_settings_for_partner()
    {
        $user = User::factory()->create(['role_id' => Role::partner->value]);
        $requestData = [
            'selected_acquirer' => 'tbank',
            'settings' => [
                'terminal_key' => 'test_key',
                'password' => 'test_pass'
            ]
        ];

        $this->service->saveAcquirerSettings($user, $requestData);

        $partner = $user->fresh()->partner;
        $this->assertNotNull($partner);
        $this->assertEquals('tbank', $partner->acquirer_settings['selected_acquirer']);
        $this->assertEquals([
            'terminal_key' => 'test_key',
            'password' => 'test_pass'
        ], $partner->acquirer_settings['settings']);
    }

    public function test_it_creates_partner_record_when_saving_settings()
    {
        $user = User::factory()->create(['role_id' => Role::partner->value]);
        // Убедимся, что партнёрская запись отсутствует
        $this->assertNull($user->partner);

        $requestData = [
            'selected_acquirer' => 'test',
            'settings' => ['test' => 'value']
        ];

        $this->service->saveAcquirerSettings($user, $requestData);

        $user->refresh();
        $this->assertNotNull($user->partner);
        $this->assertEquals($user->id, $user->partner->user_id);
    }

    public function test_it_handles_empty_request_data()
    {
        $user = User::factory()->create(['role_id' => Role::partner->value]);
        $requestData = [];

        $this->service->saveAcquirerSettings($user, $requestData);

        $partner = $user->fresh()->partner;
        $this->assertNotNull($partner);
        $this->assertNull($partner->acquirer_settings['selected_acquirer'] ?? null);
    }
}
