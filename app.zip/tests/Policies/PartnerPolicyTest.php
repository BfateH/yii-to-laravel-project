<?php

namespace Tests\Policies;

use App\Enums\Role;
use App\Models\User;
use App\Policies\PartnerPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PartnerPolicyTest extends TestCase
{
    use RefreshDatabase;

    protected PartnerPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        $this->policy = new PartnerPolicy();
    }

    public function test_only_admin_can_view_partners()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $user = User::factory()->create(['role_id' => Role::user->value]);
        $partner = User::factory()->create(['role_id' => Role::partner->value]);

        $this->assertTrue($this->policy->viewAny($admin));
        $this->assertFalse($this->policy->viewAny($user));
        $this->assertFalse($this->policy->viewAny($partner));
    }

    public function test_only_admin_can_create_partners()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $user = User::factory()->create(['role_id' => Role::user->value]);
        $partner = User::factory()->create(['role_id' => Role::partner->value]);

        $this->assertTrue($this->policy->create($admin));
        $this->assertFalse($this->policy->create($user));
        $this->assertFalse($this->policy->create($partner));
    }

    public function test_only_admin_can_update_partners()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $user = User::factory()->create(['role_id' => Role::user->value]);
        $partner = User::factory()->create(['role_id' => Role::partner->value]);
        $targetPartner = User::factory()->create(['role_id' => Role::partner->value]);

        $this->assertTrue($this->policy->update($admin, $targetPartner));
        $this->assertFalse($this->policy->update($user, $targetPartner));
        $this->assertFalse($this->policy->update($partner, $targetPartner));
    }

    public function test_admin_cannot_delete_partner_id_1()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $partner = User::factory()->create(['id' => 1, 'role_id' => Role::partner->value]);

        $this->assertFalse($this->policy->delete($admin, $partner));
        $this->assertFalse($this->policy->forceDelete($admin, $partner));
    }

    public function test_admin_can_delete_regular_partner()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $partner = User::factory()->create(['id' => 2, 'role_id' => Role::partner->value]);

        $this->assertTrue($this->policy->delete($admin, $partner));
        $this->assertTrue($this->policy->forceDelete($admin, $partner));
    }

    public function test_non_admins_cannot_delete_partners()
    {
        $user = User::factory()->create(['role_id' => Role::user->value]);
        $partnerUser = User::factory()->create(['role_id' => Role::partner->value]);
        $targetPartner = User::factory()->create(['id' => 2, 'role_id' => Role::partner->value]);

        $this->assertFalse($this->policy->delete($user, $targetPartner));
        $this->assertFalse($this->policy->forceDelete($user, $targetPartner));
        $this->assertFalse($this->policy->delete($partnerUser, $targetPartner));
        $this->assertFalse($this->policy->forceDelete($partnerUser, $targetPartner));
    }

    public function test_partner_policy_validates_partner_role()
    {
        $admin = User::factory()->create(['role_id' => Role::admin->value]);
        $regularUser = User::factory()->create(['role_id' => Role::user->value]);

        $this->assertFalse($this->policy->view($admin, $regularUser));
        $this->assertFalse($this->policy->update($admin, $regularUser));
        $this->assertFalse($this->policy->delete($admin, $regularUser));
    }
}
